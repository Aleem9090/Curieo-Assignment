﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InstantiateBalloons : MonoBehaviour {

    public GameObject green;
    public GameObject blue;
    public GameObject red;
    // Use this for initialization
    void Start()
    {
        StartCoroutine(playergeneratorGreen());
        StartCoroutine(playergeneratorBlue());
        StartCoroutine(playergeneratorRed());
    }
    IEnumerator playergeneratorGreen()
    {
        float xpos = Random.Range(-10f, 10f);
        Instantiate(green, new Vector2(xpos, 5), transform.rotation);
        yield return new WaitForSeconds(1f);
        StartCoroutine(playergeneratorGreen());
    }
    IEnumerator playergeneratorBlue()
    {
        float xpos = Random.Range(-10f, 10f);
        Instantiate(blue, new Vector2(xpos, 5), transform.rotation);
        yield return new WaitForSeconds(2f);
        StartCoroutine(playergeneratorBlue());
    }
    IEnumerator playergeneratorRed()
    {
        float xpos = Random.Range(-10f, 10f);
        Instantiate(red, new Vector2(xpos, 5), transform.rotation);
        yield return new WaitForSeconds(3f);
        StartCoroutine(playergeneratorRed());
    }
}

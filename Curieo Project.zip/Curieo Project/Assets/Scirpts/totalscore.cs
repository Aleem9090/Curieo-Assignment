﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class totalscore : MonoBehaviour {

    public Text t1;
	// Use this for initialization
	private void Start () {
        t1.text = "Total Score : " + ScoreCard.scorevalue;
	}
}

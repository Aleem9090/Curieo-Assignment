﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class movePlayer : MonoBehaviour {
    public AudioSource s1;

    public float sp = 15f;
	// Update is called once per frame
	void Update () {
        transform.Translate(new Vector2(0,-Input.GetAxis("Horizontal") * sp * Time.deltaTime));
	}
    void OnCollisionEnter2D(Collision2D hit)
    {
        if (hit.gameObject.tag == "green")
        {
            ScoreCard.scorevalue += 5;
            Destroy(hit.gameObject);
            s1.Play();
        }
        if (hit.gameObject.tag == "blue")
        {
            ScoreCard.scorevalue += 10;
            Destroy(hit.gameObject);
            s1.Play();
        }
        if (hit.gameObject.tag == "red")
        {
            ScoreCard.scorevalue += 15;
            Destroy(hit.gameObject);
            s1.Play();
        }

        }

}

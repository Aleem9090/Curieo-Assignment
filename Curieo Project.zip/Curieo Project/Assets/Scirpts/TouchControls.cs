﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TouchControls : MonoBehaviour
{

    public float speed = 20f;
    public bool right = false;
    public bool left = false;
 

    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (right)
        {
            GameObject player = GameObject.FindGameObjectWithTag("Player");
            Vector2 moveRight = new Vector2(0,-speed * Time.deltaTime);
            player.transform.Translate(moveRight);
        }
        if (left)
        {
            GameObject player = GameObject.FindGameObjectWithTag("Player");
            Vector2 moveLeft = new Vector2(0,speed * Time.deltaTime);
            player.transform.Translate(moveLeft);
        }
        
    }
    public void RightMoveDown()
    {
        right = true;
    }
    public void RightMoveUp()
    {
        right = false;
    }
    public void LeftMoveDown()
    {
        left = true;
    }
    public void LeftMoveUp()
    {
        left = false;
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class red : MonoBehaviour {

	
	// Update is called once per frame
	void Update () {
        transform.Translate(new Vector2(0, -10 * Time.deltaTime));
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreCard : MonoBehaviour {
    public static int scorevalue = 0;
    public Text score;

   // Use this for initialization
    void Start () {
        scorevalue = 0;
        score = GetComponent<Text>();
	}
	
	// Update is called once per frame
	public void Update () {
        score.text = "Score:" + scorevalue;
	}
}
